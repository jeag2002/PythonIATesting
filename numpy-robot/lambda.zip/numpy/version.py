
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.14.3'
version = '1.14.3'
full_version = '1.14.3'
git_revision = '73299826729be58cec179b52c656adfcaefada93'
release = True

if not release:
    version = full_version
